from __future__ import print_function
import numpy as np
import os

np.random.seed(1337)  # for reproducibility

from keras.preprocessing import sequence
from keras.models import model_from_json
from six.moves import cPickle

__author__ = 'Adithya Rao (adithya.rao@lithium.com)'

'''lsw_predict_single.py: Small tool run to predict provided examples for a given input model, tokenizer, and architecture.

    NOTE:
     - RNNs are tricky. Choice of batch size is important, choice of loss and optimizer is critical, etc.
       Some configurations won't converge.
     - LSTM loss decrease patterns during training can be quite different from what you see with CNNs/MLPs/etc.

    Command:
        python lsw_predict_single.py
'''

import argparse

parser = argparse.ArgumentParser(description = 'Small tool run to predict provided examples for a given input model, tokenizer, and architecture.')

parser.add_argument('--tokenizerFileName',
                    default='tokenizer_data.pkl',
                    type=str,
                    help='FileName that tokenizer will be stored in.')
parser.add_argument('--maxFeatures',
                    type=int,
                    default=40000,
                    help='Maximum number of features, this is basically size of your vocabulary.')
parser.add_argument('--skipTopFeatures',
                    type=int,
                    default=0,
                    help='How many of the top ranking features should we skip.')
parser.add_argument('--inputPath',
                    type=str,
                    help='Path that contains tokenized_dataset.pkl data set on which we do training.')
parser.add_argument('--architectureFileName',
                    default='architecture.json',
                    type=str,
                    help='FileName that tokenized data will be stored in.')
parser.add_argument('--weightsFileName',
                    default='model_weights.pkl',
                    type=str,
                    help='FileName that tokenized data will be stored in.')
parser.add_argument('--reverse',
                    type=str,
                    default='True',
                    help='Reverse order of words in text before giving to model.')


args = parser.parse_args()

def oov_data(args, x_data, oov_char=2):
    if args.reverse:
        for x in x_data:
            x.reverse()

    # by convention, use 2 as OOV word
    # reserve 'index_from' (=3 by default) characters: 0 (padding), 1 (start), 2 (OOV)
    if oov_char is not None:
        return [[oov_char if (w >= args.maxFeatures or w <= args.skipTopFeatures) else w for w in x] for x in x_data]
    else:
        nX = []
        for x in x_data:
            nx = []
            for w in x:
                if w <= args.maxFeatures or w > args.skipTopFeatures:
                    nx.append(w)
            nX.append(nx)
        return nX


def load_model(model_folder, architecture_file_name, weights_file_name):
    print('Loading model from path %s ' % model_folder)

    # Load architecture
    architecture_path = model_folder + architecture_file_name
    print('Loading architecture from %s.' % architecture_path)
    if not os.path.exists(architecture_path):
        print(architecture_path + ' does not exist.')
        return None
    model = model_from_json(open(architecture_path).read())

    weights_path = model_folder + weights_file_name
    print("Loading weights from %s." % weights_path)
    if not os.path.exists(weights_path):
        print(weights_path + ' does not exist.')
        return None
    model.load_weights(weights_path)
    return model


def load_tokenizer(model_folder, tokenizer_file_name):
    tokenizer_path = model_folder + tokenizer_file_name
    print("Loading tokenizer from %s." % tokenizer_path)
    if not os.path.exists(tokenizer_path):
        print(tokenizer_path + ' does not exist.')
        return None
    return cPickle.load(open(tokenizer_path, 'rb'))

def load_model_tokenizer(args):
    model_folder = args.inputPath + '/'
    if not os.path.isdir(model_folder):
        print(model_folder + ' is not a directory')
        exit(1)
    model = load_model(model_folder, args.architectureFileName, args.weightsFileName)
    tokenizer = load_tokenizer(model_folder, args.tokenizerFileName)
    return model, tokenizer


def predict(model, tokenizer, text):
    print("Tokenizing text .. ")
    tokenized_data = tokenizer.texts_to_sequences([text])
    x_oov = oov_data(args, tokenized_data)

    input_len = model.input_shape[1]
    x_pad = sequence.pad_sequences(x_oov, maxlen=input_len)
    print(x_pad)

    print("Predicting .. ")
    prediction = model.predict_classes(x_pad, batch_size=32)
    proba = model.predict_proba(x_pad, batch_size=32)
    return prediction, proba


def main():
    model, tokenizer = load_model_tokenizer(args)

    # Demo first prediction.
    text = '@bradycanoe @48ONIRAM @TheSixFinger @jdotsett I started with "The Wild, The innocent" cause Spotify has their listing backwards & its good!'
    print('Processing input text: ', text)

    prediction, probability = predict(model, tokenizer, text)
    print('Predicted class        : ', prediction)
    print('Prediction probability : ', probability)

    print('Type (q) to quit.')
    while True:
        # Get input.
        text = raw_input('Enter text for classification:')

        # Break if user types q.
        if text == 'q':
            break

        # Display value.
        print('Processing input text: ', text)

        prediction, probability = predict(model, tokenizer, text.lower())
        print('Predicted class        : ', prediction)
        print('Prediction probability : ', probability)


if __name__ == '__main__':
    main()
